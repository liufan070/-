// 引用百度地图微信小程序JSAPI模块
let bmap = require('../libs/bmap-wx/bmap-wx.min.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    ak: "L6XB4Nrzsk5qISBn6Ib0D8wSnlhAltmn",
    weatherData: '',
    futureWeather: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    // 新建bmap对象
    let BMap = new bmap.BMapWX({
      ak: that.data.ak
    });
    let fail = function (data) {
      console.log(data);
    };
    let success = function (data) {
      console.log(data);

      let weatherData = data.currentWeather[0];
      let futureWeather = data.originalData.results[0].weather_data;
      weatherData = '城市：' + weatherData.currentCity + '\n' + 'PM2.5:' + weatherData.pm25 + '\n' + '日期:' + weatherData.date + '\n' + '温度:' + weatherData.temperature + '\n' + weatherData.weatherDesc + '\n' + '风力:' + weatherData.wind + '\n';
      that.setData({
        weatherData: weatherData,
        futureWeather: weatherData
      });
    };

    // 发起weather请求
    BMap.weather({
      fail,
      success
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})