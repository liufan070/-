var app = getApp()
Page({
  data: {


    //这是轮播图图片
    imgUrls: [
      '/photo1.jpg',
      '/photo2.jpg',
      '/photo3.jpg',
      '/photo4.jpg',
      '/photo6.jpg'
      
    ],
    indicatorDots: true, //是否显示面板指示点
    autoplay: true, //是否自动切换
    interval: 3000, //自动切换时间间隔,3s
    duration: 1000, //  滑动动画时长1s
  },
  gotopage:function(){
    wx.navigateTo({
      url: '/pages/note/note',
    })
  },
   gotopageq: function () {
    wx.navigateTo({
      url: '/pages/tianqi/tianqi',
    })
  },
  gotopagew: function () {
    wx.navigateTo({
      url: '/pages/getSubject/getSubject',
    })
  },
  gotopaget: function () {
    wx.navigateTo({
      url: '/pages/getSubject/getSubject',
    })
  },
  
})


